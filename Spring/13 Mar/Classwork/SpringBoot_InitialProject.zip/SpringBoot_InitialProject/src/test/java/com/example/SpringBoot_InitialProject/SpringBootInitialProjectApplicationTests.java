package com.example.SpringBoot_InitialProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootInitialProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
